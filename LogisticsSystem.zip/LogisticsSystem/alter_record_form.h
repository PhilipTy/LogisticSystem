#ifndef ALTER_RECORD_FORM_H
#define ALTER_RECORD_FORM_H

#include <QWidget>

namespace Ui {
class alter_record_form;
}

class alter_record_form : public QWidget
{
    Q_OBJECT

public:
    explicit alter_record_form(QWidget *parent = nullptr);
    ~alter_record_form();

private slots:
    void on_ensure_btn_clicked();
    void on_reset_btn_clicked();
    void on_cancel_btn_clicked();
    void displayAllInformation(QString data);   //显示全部

private:
    Ui::alter_record_form *ui;
    QString record_id_global;
};

#endif // ALTER_RECORD_FORM_H
