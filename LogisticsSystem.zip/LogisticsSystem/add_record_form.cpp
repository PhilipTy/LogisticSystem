#include "add_record_form.h"
#include "ui_add_record_form.h"
#include <QMessageBox>
#include <QString>
#include <QSqlQuery>


add_record_form::add_record_form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::add_record_form)
{
    ui->setupUi(this);
    this->setWindowTitle("添加物流记录");
    setWindowIcon(QIcon(":/logo.ico"));
}

add_record_form::~add_record_form()
{
    delete ui;
}

void add_record_form::on_ensure_btn_clicked()
{
    QString record_id;
    QString cust_name;
    QString address;
    QString staff_name;
    QString cust_phone;
    QString number;
    QString admin;
    QSqlQuery query;

    record_id = ui->record_no_le->text().trimmed();
    cust_name = ui->cust_name_le->text().trimmed();
    address = ui->address_le->text().trimmed();
    staff_name = ui->staff_le->text().trimmed();
    cust_phone = ui->cust_phone_le->text().trimmed();
    number = ui->state_le->text().trimmed();
    admin = "0000";

    query.exec("select record_no from warehouse where record_no = '" + record_id + "'");

    if (!query.next())
    {
        if (record_id != "" && cust_name != "" && address != "")
        {
            if (cust_phone != "" && staff_name != "" && number != "")
            {
                query.prepare(tr("insert into warehouse values(:id, :name, :address, :cust_phone, :staff_name, :num, :admin)"));
                query.bindValue(":id", record_id);
                query.bindValue(":name", cust_name);
                query.bindValue(":address", address);
                query.bindValue(":cust_phone", cust_phone);
                query.bindValue(":staff_name", staff_name);
                query.bindValue(":num", number);
                query.bindValue(":admin", admin);
                query.exec();

                if (query.isActive())
                {
                    query.numRowsAffected();
                    QMessageBox::information(this, tr("信息"), tr("数据插入成功！"));
                    this->close();
                }
            }
            else
                QMessageBox::warning(this, tr("警告"), tr("有关信息不能为空！"));
            }
        else
            QMessageBox::warning(this, tr("警告"), tr("有关信息不能为空！"));
    }
    else
    {
        QMessageBox::warning(this, tr("警告"), tr("物流号是唯一，不能重复！"));
        return ;
    }
}


void add_record_form::on_reset_btn_clicked()
{
    ui->record_no_le->setText("");
    ui->cust_name_le->setText("");
    ui->cust_phone_lab->setText("");
    ui->address_le->setText("");
    ui->staff_le->setText("");
    ui->state_le->setText("");
}

void add_record_form::on_cancel_btn_clicked()
{
    this->close();
}
