#include "user_login.h"
#include "ui_user_login.h"

#include "user_register_form.h"
#include "connect_database.h"

#include <QMessageBox>
#include <QDesktopWidget>
#include <QSqlQuery>


user_login::user_login(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::user_login)
{
    ui->setupUi(this);
    this->setWindowTitle("WELCOME");
    setWindowIcon(QIcon(":/logo.ico"));
    //用户索引计数器
    admin_counter = 0;
    staff_counter = 0;
    counter = 0;
}

user_login::~user_login()
{
    delete ui;
}

void user_login::on_login_btn_clicked()
{
    bool flag = false;

    QString user_account;
    QString user_pwd;
    QString user_type;

    user_account = ui->acnt_le->text();
    user_pwd  = ui->pwd_le->text();
    user_type = ui->type_cbx->currentText();

    QSqlQuery query;

    if (!ConnectDatabase::openDatabase())
    {
        QMessageBox::warning(this, tr("连接MySQL数据库失败"), tr("检查mysql驱动相关ddl配置文件"));
        return ;
    }
    else
    {
        if (user_type == tr("管理员"))
        {
            query.exec("select * from admin");
            while (query.next())
            {
                if (query.value(0).toString() == user_account)
                    if (query.value(3).toString() == user_pwd)
                    {
                        if (admin_counter < 1)
                        {
                            admin_form  *admin = new admin_form();
                            flag = true;
                            admin->show();
                            admin->move((QApplication::desktop()->width() -
                                         admin->width()) / 2,
                                        (QApplication::desktop()->height() -
                                         admin->height()) / 2);
                            this->hide();
                              admin_counter++;
                              counter++;
                              if (counter == 2)
                                  this->close();
                        }
                        else
                        {
                            QMessageBox::warning(this, tr("警告"),
                                                 tr("不能有多个用户同时在线！"));
                            return ;
                        }
                    }
            }
        }
        else if (user_type == tr("员工"))
        {
            query.exec("select * from staff");
            while (query.next())
            {
                if (query.value(0).toString() == user_account)
                    if (query.value(2).toString() == user_pwd)
                    {
                        if (staff_counter < 1)
                        {
                            staff_system_form *staff = new staff_system_form();
                            flag = true;
                            staff->show();
                            staff->move((QApplication::desktop()->width() -
                                          staff->width()) / 2,
                                         (QApplication::desktop()->height() -
                                          staff->height()) / 2);
                            this->hide();
                            staff_counter++;
                            counter++;
                            if (counter == 2)
                                this->close();
                        }
                        else
                        {
                            QMessageBox::warning(this, tr("警告"),
                                                 tr("不能有多个用户同时在线！"));
                            return ;
                        }
                    }
            }
        }
        if (!flag)
            QMessageBox::warning(this, tr("警告"), tr("用户名或密码错误! "));
    }

}


void user_login::on_quit_btn_clicked()
{
    this->close();
}


void user_login::on_reg_btn_clicked()
{
    QSqlQuery query;

    if (!ConnectDatabase::openDatabase())
    {
        QMessageBox::warning(this, tr("连接MySQL数据库失败"), tr("检查mysql驱动相关ddl配置文件"));
        return ;
    }
    else
    {
        user_register_form *user_register = new user_register_form();
        user_register->show();
        user_register->move((QApplication::desktop()->width() -
                             user_register->width()) / 2,
                            (QApplication::desktop()->height() -
                             user_register->height()) / 2);
    }

}
