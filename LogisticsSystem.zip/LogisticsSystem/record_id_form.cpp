#include "record_id_form.h"
#include "ui_record_id_form.h"
#include "alter_record_form.h"
#include <QMessageBox>
#include <QString>
#include <QSqlQuery>
#include <QDesktopWidget>


record_id_form::record_id_form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::record_id_form)
{
    ui->setupUi(this);
    this->setWindowTitle("输入要修改的物流号 ");
    setWindowIcon(QIcon(":/logo.ico"));
}

record_id_form::~record_id_form()
{
    delete ui;
}

void record_id_form::on_ensure_btn_clicked()
{
    QString record_id;
    QSqlQuery query;

    record_id = ui->record_no_le->text().trimmed();
    query.exec("select record_no from warehouse where record_no = '" + record_id + "'");

    if (query.next())
    {
        alter_record_form *alter_record = new alter_record_form();
        alter_record->show();
        alter_record->move((QApplication::desktop()->width() - alter_record->width()) / 2,
                         (QApplication::desktop()->height() - alter_record->height()) / 2);
        //关联 信号：修改物流 和 槽：显示全部
        connect(this, SIGNAL(send_record_id(QString)), alter_record, SLOT(displayAllInformation(QString)));
        emit send_record_id(record_id);     //发射信号

        this->close();
    }
    else
        QMessageBox::warning(this, tr("错误"), tr("不存在该物流记录！"));
}


void record_id_form::on_cancel_btn_clicked()
{
    this->close();
}
