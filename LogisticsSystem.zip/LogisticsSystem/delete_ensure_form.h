#ifndef DELETE_ENSURE_FORM_H
#define DELETE_ENSURE_FORM_H

#include <QWidget>

namespace Ui {
class delete_ensure_form;
}

class delete_ensure_form : public QWidget
{
    Q_OBJECT

public:
    explicit delete_ensure_form(QWidget *parent = nullptr);
    ~delete_ensure_form();

private slots:
    void on_yes_btn_clicked();
    void on_no_btn_clicked();

private:
    Ui::delete_ensure_form *ui;
};

#endif // DELETE_ENSURE_FORM_H
