#include "staff_system_form.h"
#include "ui_staff_system_form.h"
#include "user_login.h"
#include "admin_form.h"

#include <QTimer>
#include <QtMath>
#include <QString>
#include <QDebug>
#include <QMessageBox>
#include <QModelIndex>
#include <QDate>
#include <QDateTime>
#include <QTableWidget>
#include <QDesktopWidget>
#include <QAbstractItemView>
#include <QSqlQuery>
#include <QSqlRecord>


staff_system_form::staff_system_form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::staff_system_form)
{
    ui->setupUi(this);
    this->setWindowTitle("员工物流管理系统");
    setWindowIcon(QIcon(":/logo.ico"));

    ui->staff_system_tw->setCurrentIndex(0);
    ui->cust_name_le->setEnabled(false);
    ui->cust_phone_le->setEnabled(false);
    ui->staff_name_le->setEnabled(false);

    properties = " record_no, cust_name, tname, cust_phone, staff_name, bnum, tloc ";
    tables = " warehouse, address ";

    record_query_model = new QSqlQueryModel(this);
    record_query_model->setQuery("select" + properties + "from" + tables +
                               "where addno = tno");
    record_query_model->setHeaderData(0, Qt::Horizontal, tr("物流号"));
    record_query_model->setHeaderData(1, Qt::Horizontal, tr("客户姓名"));
    record_query_model->setHeaderData(2, Qt::Horizontal, tr("地址"));
    record_query_model->setHeaderData(3, Qt::Horizontal, tr("客户电话"));
    record_query_model->setHeaderData(4, Qt::Horizontal, tr("负责员工"));
    record_query_model->setHeaderData(5, Qt::Horizontal, tr("数量"));
    record_query_model->setHeaderData(6, Qt::Horizontal, tr("位置"));

    ui->record_tv->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->record_tv->setModel(record_query_model);
    ui->record_tv->show();

    record_export_model = new QSqlTableModel(this);
    record_export_model->setTable("warehouse");
    record_export_model->setEditStrategy(QSqlTableModel::OnManualSubmit);
    record_export_model->setHeaderData(0, Qt::Horizontal, tr("物流号"));
    record_export_model->setHeaderData(1, Qt::Horizontal, tr("客户姓名"));
    record_export_model->setHeaderData(2, Qt::Horizontal, tr("客户电话"));
    record_export_model->setHeaderData(3, Qt::Horizontal, tr("负责员工"));
    record_export_model->setHeaderData(4, Qt::Horizontal, tr("数量"));
    record_export_model->removeColumn(record_export_model->fieldIndex("addno"));
    record_export_model->removeColumn(record_export_model->fieldIndex("ano"));
//    record_export_model->removeColumn(record_export_model->fieldIndex("bnum"));
    record_export_model->select();

    ui->export_tv->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->export_tv->setModel(record_export_model);
    ui->export_tv->show();

    ui->export_tw->setEditTriggers(QAbstractItemView::NoEditTriggers);

    QDate date = QDate::currentDate();
    ui->renew_de->setDate(date);

    this->record_noBind();

    this->emptyrecordMap();
    this->emptyexportMap();

    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(timerUpdateView()));
    timer->start(5000);
}

staff_system_form::~staff_system_form()
{
    delete ui;
}


void staff_system_form::timerUpdateView()
{
//    properties = " record_no, cust_name, address, cust_phone, staff_name, state, tloc ";
//    tables = " record, address ";

//    record_query_model = new QSqlQueryModel(this);
//    record_query_model->setQuery("select" + properties + "from" + tables +
//                               "where addno = tno");
//    record_query_model->setHeaderData(0, Qt::Horizontal, tr("物流号码"));
//    record_query_model->setHeaderData(1, Qt::Horizontal, tr("客户"));
//    record_query_model->setHeaderData(2, Qt::Horizontal, tr("地址"));
//    record_query_model->setHeaderData(3, Qt::Horizontal, tr("客户电话"));
//    record_query_model->setHeaderData(4, Qt::Horizontal, tr("员工"));
//    record_query_model->setHeaderData(5, Qt::Horizontal, tr("状况"));
//    record_query_model->setHeaderData(6, Qt::Horizontal, tr("位置"));
//    ui->record_tv->setEditTriggers(QAbstractItemView::NoEditTriggers);
//    ui->record_tv->setModel(record_query_model);
//    ui->record_tv->show();

    record_export_model->setFilter(QObject::tr("record_no like '%'"));
    record_export_model->select();
}


void staff_system_form::emptyrecordMap()//空记录
{
    QSqlQuery query;
    QSqlRecord record;
    QString record_id;
    query.exec("select record_no from warehouse");

    while(query.next())
    {
        record = query.record();
        record_id = query.value(record.indexOf("record_no")).toString();
        record_num_map.insert(record_id ,0);
    }
}


void staff_system_form::emptyexportMap()
{
    QSqlQuery query;
    QSqlRecord record;
    QString record_id;
    query.exec("select record_no from warehouse");

    while(query.next())
    {
        record = query.record();
        record_id = query.value(record.indexOf("record_no")).toString();
        renew_num_map.insert(record_id ,0);
    }
}


void staff_system_form::emptySomeMap(QString record_id)
{
    record_num_map[record_id] = 0;
}


void staff_system_form::on_search_btn_clicked()
{
    QString cust_name;
    QString cust_phone;
    QString staff_name;

    cust_name = ui->cust_name_le->text().trimmed();
    cust_phone = ui->cust_phone_le->text().trimmed();
    staff_name = ui->staff_name_le->text().trimmed();

    QSqlQueryModel *model = new QSqlQueryModel;

    if (ui->cust_name_ckx->isChecked())//勾选：按客户名查找
    {
        if (ui->cust_phone_ckx->isChecked())
            if (ui->staff_name_ckx->isChecked())
                model->setQuery("select" + properties + "from" + tables +
                                "where addno = tno and cust_name like '" + cust_name +
                                "%'" + "and cust_phone like '" + cust_phone + "%'" +
                                "and staff_name like '" + staff_name + "%'");//根据员工索引
            else
                model->setQuery("select" + properties + "from" + tables +
                                "where addno = tno and cust_name like '" + cust_name +
                                "%'" + "and cust_phone like '" + cust_phone + "%'");//根据客户电话索引
        else if (ui->staff_name_ckx->isChecked())
            model->setQuery("select" + properties + "from" + tables +
                            "where addno = tno and cust_name like '" + cust_name + "%'" +
                            "and staff_name like '" + staff_name + "%'");//根据员工索引
        else
            model->setQuery("select" + properties + "from" + tables +
                            "where addno = tno and cust_name like '" + cust_name + "%'");
    }
    else if (ui->cust_phone_ckx->isChecked())
    {
        if (ui->staff_name_ckx->isChecked())
            model->setQuery("select" + properties + "from" + tables +
                            "where addno = tno and cust_phone like '" + cust_phone + "%'" +
                            "and staff_name like '" + staff_name + "%'");
        else
            model->setQuery("select" + properties + "from" + tables +
                            "where addno = tno and cust_phone like '" + cust_phone + "%'");
    }
    else if (ui->staff_name_ckx->isChecked())
        model->setQuery("select" + properties + "from" + tables +
                        "where addno = tno and staff_name like '" + staff_name + "%'");

    model->setHeaderData(0, Qt::Horizontal, tr("物流号"));
    model->setHeaderData(1, Qt::Horizontal, tr("客户姓名"));
    model->setHeaderData(2, Qt::Horizontal, tr("地址"));
    model->setHeaderData(3, Qt::Horizontal, tr("客户电话"));
    model->setHeaderData(4, Qt::Horizontal, tr("负责员工"));
    model->setHeaderData(5, Qt::Horizontal, tr("数量"));
    model->setHeaderData(6, Qt::Horizontal, tr("位置"));

    ui->record_tv->setModel(model);
    ui->record_tv->show();
}


void staff_system_form::on_dis_all_btn_clicked()//“全部显示”按钮按下
{
    QSqlQueryModel *model = new QSqlQueryModel;
    model->setQuery("select" + properties + "from" + tables + "where addno = tno");
    model->setHeaderData(0, Qt::Horizontal, tr("物流号"));
    model->setHeaderData(1, Qt::Horizontal, tr("客户姓名"));
    model->setHeaderData(2, Qt::Horizontal, tr("地址"));
    model->setHeaderData(3, Qt::Horizontal, tr("客户电话"));
    model->setHeaderData(4, Qt::Horizontal, tr("负责员工"));
    model->setHeaderData(5, Qt::Horizontal, tr("数量"));
    model->setHeaderData(6, Qt::Horizontal, tr("位置"));

    ui->record_tv->setModel(model);
    ui->record_tv->show();
}


void staff_system_form::on_reset_btn_1_clicked()//重置按钮按下
{
    ui->cust_name_le->setText("");
    ui->cust_phone_le->setText("");
    ui->staff_name_le->setText("");
    ui->record_no_cmx->setCurrentText("0000");
}


void staff_system_form::on_locate_btn_clicked()
{
    QString record_id;

    record_id = ui->record_no_cmx->currentText().trimmed();

    QSqlQueryModel *model = new QSqlQueryModel;
    model->setQuery("select" + properties + "from" + tables +
                    "where addno = tno and record_no = '" + record_id + "'");
    model->setHeaderData(0, Qt::Horizontal, tr("物流号"));
    model->setHeaderData(1, Qt::Horizontal, tr("客户姓名"));
    model->setHeaderData(2, Qt::Horizontal, tr("地址"));
    model->setHeaderData(3, Qt::Horizontal, tr("客户电话"));
    model->setHeaderData(4, Qt::Horizontal, tr("负责员工"));
    model->setHeaderData(5, Qt::Horizontal, tr("数量"));
    model->setHeaderData(6, Qt::Horizontal, tr("位置"));

    ui->record_tv->setModel(model);
    ui->record_tv->show();
}


void staff_system_form::record_noBind()
{
    ui->record_no_cmx->clear();

    QSqlQuery query;
    query.exec("select record_no from record");

    while(query.next())
    {
        ui->record_no_cmx->insertItem(0, query.value(0).toString());
    }
}


void staff_system_form::on_cust_name_ckx_clicked()
{
    if (ui->cust_name_ckx->isChecked())
        ui->cust_name_le->setEnabled(true);
    else
        ui->cust_name_le->setEnabled(false);
}


void staff_system_form::on_cust_phone_ckx_clicked()
{
    if (ui->cust_phone_ckx->isChecked())
        ui->cust_phone_le->setEnabled(true);
    else
        ui->cust_phone_le->setEnabled(false);
}


void staff_system_form::on_staff_name_ckx_clicked()
{
    if (ui->staff_name_ckx->isChecked())
        ui->staff_name_le->setEnabled(true);
    else
        ui->staff_name_le->setEnabled(false);
}


void staff_system_form::on_add_btn_clicked()
{
    QString record_id;
    QString cust_name;
    QString staff_name;
    QString cust_phone;
    QString export_cust_name;

    int record_num;
    int record_num_all;
    int repeat_flag = 0;

    if (ui->export_tv->currentIndex().row() < 0)
    {
        QMessageBox::warning(this, tr("提示"), tr("请添加物流信息！"));
        return ;
    }

    QModelIndex index = ui->export_tv->currentIndex();

    record_id = record_export_model->record(
                            index.row()).value("record_no").toString();
    cust_name  = record_export_model->record(
                            index.row()).value("cust_name").toString();
    staff_name = record_export_model->record(
                            index.row()).value("staff_name").toString();
    cust_phone = record_export_model->record(
                            index.row()).value("cust_phone").toString();
    record_num = record_export_model->record(
                            index.row()).value("bnum").toInt();

    record_itera = record_num_map.find(record_id);
    record_num_all = 1 + record_itera.value();

    if (record_num_all <= record_num)
    {
        record_id_order.append(record_id);

        for (int i = 0; i < ui->export_tw->rowCount(); i++)
        {
            export_cust_name = ui->export_tw->item(i, 0)->text();

            if (export_cust_name == cust_name)
            {
                QTableWidgetItem *item = new QTableWidgetItem(
                                         QString::number(record_num_all));
                ui->export_tw->setItem(i, 2, item);
    //            QTableWidgetItem *item = new QTableWidgetItem(QString::number());
    //            QTableWidgetItem *item = ui->export_tw->item(i, 2);
    //            after_export_state = item->text().toInt();
    //            after_export_state++;
    //            item->setText(QString::number(after_export_state));
    //            ui->export_tw->setItem(i, 2, item);
                repeat_flag = 1;
                break;
            }
        }

        if (repeat_flag == 0)
        {
            QTableWidgetItem *item0 = new QTableWidgetItem(cust_name);
            QTableWidgetItem *item1 = new QTableWidgetItem(staff_name);
            QTableWidgetItem *item2 = new QTableWidgetItem(QString::number(
                                                           record_num_all));
            QTableWidgetItem *item3 = new QTableWidgetItem(cust_phone);

            int row = ui->export_tw->rowCount();

            ui->export_tw->setRowCount(row + 1);
            ui->export_tw->setItem(row, 0, item0);
            ui->export_tw->setItem(row, 1, item1);
            ui->export_tw->setItem(row, 2, item2);
            ui->export_tw->setItem(row, 3, item3);
        }
        record_num_map[record_id] = record_num_all;
        ui->record_no_le->setText(record_id);
        ui->bnum_le->setText(QString::number(record_num_all));
    }
    else
    {
        QMessageBox::warning(this, tr("警告"), tr("出库量超过仓库总量！"));
        record_num_all = record_num_all - 1;
    }
}


void staff_system_form::on_add_btn_2_clicked()
{
    QString record_id;
    QString staff_name;
    QString cust_phone;
    QString cust_name;
    QString export_cust_name;
    int record_num_in;
    int record_num_all;
    int repeat_flag = 0;
    QSqlQuery query;

    record_id = ui->record_no_le->text().trimmed();
    record_num_in = ui->bnum_le->text().trimmed().toInt();

    if (record_id != "" && record_num_in != 0)
    {
        query.exec("select * from record where record_no = '" + record_id + "'");

        if (query.next())
        {
            QSqlRecord record = query.record();

            record_itera = record_num_map.find(record_id);
            record_num_all = record_num_in + record_itera.value();

            if (record_num_all <= query.value(record.indexOf("bnum")).toInt())
            {
                record_id_order.append(record_id);

                cust_name = query.value(record.indexOf("cust_name")).toString();
                staff_name = query.value(record.indexOf("staff_name")).toString();
                cust_phone = query.value(record.indexOf("cust_phone")).toString();

                for (int i = 0; i < ui->export_tw->rowCount(); i++)
                {
                    export_cust_name = ui->export_tw->item(i, 0)->text();

                    if (export_cust_name == cust_name)
                    {
                        QTableWidgetItem *item = new QTableWidgetItem(
                                                 QString::number(record_num_all));
                        ui->export_tw->setItem(i, 2, item);
                        repeat_flag = 1;
                        break;
                    }
                }

                if (repeat_flag == 0)
                {
                    QTableWidgetItem *item0 = new QTableWidgetItem(
                                                  cust_name);
                    QTableWidgetItem *item1 = new QTableWidgetItem(
                                                  staff_name);
                    QTableWidgetItem *item2 = new QTableWidgetItem(QString::number(
                                                  record_num_all));
                    QTableWidgetItem *item3 = new QTableWidgetItem(
                                                  cust_phone);

                    int row = ui->export_tw->rowCount();

                    ui->export_tw->setRowCount(row + 1);
                    ui->export_tw->setItem(row, 0, item0);
                    ui->export_tw->setItem(row, 1, item1);
                    ui->export_tw->setItem(row, 2, item2);
                    ui->export_tw->setItem(row, 3, item3);
                }
                record_num_map[record_id] = record_num_all;
            }
            else
            {
                QMessageBox::warning(this, tr("警告"), tr("出库量超过仓库总量！"));
                record_num_all = record_num_all - record_num_in;
            }
        }
        else
            QMessageBox::warning(this, tr("警告"), tr("没有对应的物流号！"));
    }
    else
        QMessageBox::warning(this, tr("警告"), tr("物流号或数量不能为空！"));
}


void staff_system_form::on_delete_btn_clicked()
{
    QString record_id;
    QModelIndex index;

    int current_row = ui->export_tw->currentIndex().row();
    ui->export_tw->removeRow(current_row);

    index = ui->export_tv->currentIndex();
    record_id = record_export_model->record(index.row()).value("record_no").toString();
    this->emptySomeMap(record_id);
}


void staff_system_form::on_reset_btn_2_clicked()
{
    ui->staff_no_le->setText("");
    ui->record_no_le->setText("");
    ui->bnum_le->setText("");
    ui->staff_key_le->setText("");

    record_id_order.clear();;

    this->emptyrecordMap();
}


void staff_system_form::on_done_btn_clicked()
{
    QString staff_id;
    QString staff_pwd;
    QSqlQuery query_check;
    int row;

    staff_id = ui->staff_no_le->text().trimmed();
    staff_pwd = ui->staff_key_le->text().trimmed();
    row = ui->export_tw->rowCount();

    if (staff_id.isEmpty() || staff_pwd.isEmpty())
    {
        QMessageBox::warning(this, tr("警告"), tr("员工号或密码不能为空！"));
        return ;
    }
    if (row == 0)
    {
        QMessageBox::warning(this, tr("警告"), tr("请选择需要操作的物流记录！"));
        return ;
    }

    query_check.exec("select staff_no, staff_key from staff where staff_no = '" + staff_id + "'");

    if (query_check.next())
    {
        QSqlRecord rec = query_check.record();
        if (staff_pwd == query_check.value(rec.indexOf("staff_key")).toString())
        {
            QSqlQuery query;
            QSqlQuery query_update;
            QSqlQuery query_insert;

            QString record_id;
            int record_num;
            int insert_success_flag;
            int update_success_flag;

            for (int i = 0; i < record_id_order.size(); i++)
            {
                record_id = record_id_order[i];

                query.exec("select bnum from record where record_no = '" + record_id + "'");
                if (query.next())
                {
                    QSqlRecord record = query.record();
                    record_num = query.value(record.indexOf("bnum")).toInt();
                }
                else
                    continue;

                QString properties = "staff_no, record_no, edate, sdate, rdate, flag";
                QString values = ":staff_no, :record_no, :edate, :sdate, :rdate, :flag";
                QDate date = QDate::currentDate();
                QString start_date = date.toString("yyyy-MM-dd");
                QString end_date = date.addDays(30).toString("yyyy-MM-dd");

                query_insert.prepare("insert into export (" + properties + ") values ("
                                     + values + ")");
                query_insert.bindValue(":staff_no", staff_id);
                query_insert.bindValue(":record_no", record_id);
                query_insert.bindValue(":sdate", start_date);
                query_insert.bindValue(":edate", end_date);
                query_insert.bindValue(":flag", QString("出库请求"));
                query_insert.exec();

                if (query_insert.isActive())
                {
                    insert_success_flag = 1;
                    QMessageBox::information(this,tr("提示"), tr("出库请求申请成功！"));
                    record_num--;
                }
                else
                {
                    insert_success_flag = 0;
                    QMessageBox::warning(this, tr("警告"), tr("出库请求申请失败！"));
                    return ;
                }
                query_update.prepare("update record set bnum = :bnum where record_no = :record_no");
                query_update.bindValue(":record_no", record_id);
                query_update.bindValue(":bnum", record_num);
                query_update.exec();

                if (query_update.isActive())
                {
                    update_success_flag = 1;
                    QMessageBox::information(this, tr("提示"), tr("更新物流数据表成功！"));
                }
                else
                {
                    update_success_flag = 0;
                    QMessageBox::warning(this, tr("警告"), tr("更新物流数据表失败！"));
                }
            }
            record_id_order.clear();
            if (insert_success_flag == 1)
                QMessageBox::information(this,tr("提示"), tr("出库请求申请成功！"));
            else
                QMessageBox::warning(this, tr("警告"), tr("出库请求申请失败！"));
            if (update_success_flag == 1)
                QMessageBox::information(this, tr("提示"), tr("更新物流数据表成功！"));
            else
                QMessageBox::warning(this, tr("警告"), tr("更新物流数据表失败！"));
        }
        else
        {
            QMessageBox::warning(this, tr("警告"), tr("密码错误！"));
            return ;
        }
    }
    else
        QMessageBox::warning(this, tr("警告"), tr("员工身份验证失败！"));

    record_export_model->setFilter(QObject::tr("record_no like '%'"));
    record_export_model->select();
}


void staff_system_form::on_accept_btn_clicked()
{
    QString staff_id;
    QString record_id;
    QString properties;
    QSqlQuery query;
    int renew_num;

    staff_id = ui->staff_no_le_2->text().trimmed();
    record_id = ui->record_no_le_2->text().trimmed();

    if (staff_id.isEmpty() || record_id.isEmpty())
    {
        QMessageBox::warning(this, tr("警告"), tr("员工号或物流号不能为空！"));
        return ;
    }

    query.prepare("select * from export where staff_no = :staff_no and record_no = :record_no");
    query.bindValue(":staff_no", staff_id);
    query.bindValue(":record_no", record_id);
    query.exec();

    if (!query.next())
    {
        QMessageBox::warning(this, tr("警告"), tr("仓库表中没有对应的员工物流信息！"));
        return ;
    }

    query.prepare("select * from export where staff_no = :staff_no and record_no = :record_no");
    query.bindValue(":staff_no", staff_id);
    query.bindValue(":record_no", record_id);
    query.exec();

    while (query.next())
    {
        QSqlRecord record = query.record();
        QString flag = query.value(record.indexOf("flag")).toString();
        QDate end_date = query.value(record.indexOf("edate")).toDate();
//        QDate current_date = QDate::currentDate();
        QDate current_date = ui->renew_de->date();

        int days = current_date.daysTo(end_date);

        renew_itera = renew_num_map.find(record_id);
        renew_num = renew_itera.value();

        if (flag == "同意出库续租请求")
        {
            QMessageBox::information(this, tr("提示"), tr("请勿重复操作！"));
            return ;
        }

        if (flag == "同意出库请求")
        {
            if (renew_num == 0)
            {
                if (days > 0)
                {
                    QMessageBox::information(this, tr("提示"), tr("没有超过截止期限，无法续组"));
                    return ;
                }
                else if ((days <= 0) && (days >= -5))
                {
                    properties = " edate = :edate, flag = :flag ";
                    QString new_end_date;
                    new_end_date = end_date.addDays(abs(days) + 10).toString("yyyy-MM-dd");
                    query.prepare("update export set" + properties +
                                  "where staff_no = :staff_no and record_no = :record_no and flag = '同意出库请求'");
                    query.bindValue(":staff_no", staff_id);
                    query.bindValue(":record_no", record_id);
                    query.bindValue(":edate", new_end_date);
                    query.bindValue(":flag", QString("续租请求 "));
                    query.exec();

                    if (query.isActive())
                    {
                        QMessageBox::information(this, tr("提示"), tr("续租请求申请成功！"));
                        renew_num_map[record_id] = 1;
                    }
                    else
                        QMessageBox::warning(this, tr("警告"), tr("续租请求申请失败！"));
                }
                else
                    QMessageBox::warning(this, tr("警告"), tr("已超违约期限，无法续租！"));
            }
            else
                QMessageBox::warning(this, tr("警告"), tr("请勿重复操作！"));
        }
        else
            QMessageBox::warning(this, tr("警告"), tr("没有员工已出库的信息！"));
    }
}


void staff_system_form::on_cancel_btn_clicked()
{
    QDate date = QDate::currentDate();
    ui->staff_no_le_2->setText("");
    ui->record_no_le_2->setText("");
    ui->renew_de->setDate(date);
}


void staff_system_form::on_accept_btn_2_clicked()
{
    QString staff_id;
    QString record_id;
    QString flag;
    QString properties;
    QSqlQuery query;

    staff_id = ui->staff_no_le_3->text().trimmed();
    record_id = ui->record_no_le_3->text().trimmed();

    if (staff_id.isEmpty() || record_id.isEmpty())
    {
        QMessageBox::warning(this, tr("警告"), tr("员工号或物流号不能为空！"));
        return ;
    }

    query.prepare("select * from export where staff_no = :staff_no and record_no = :record_no");
    query.bindValue(":staff_no", staff_id);
    query.bindValue(":record_no", record_id);
    query.exec();

    if (!query.next())
    {
        QMessageBox::warning(this, tr("警告"), tr("出库表中没有对应的员工物流信息！"));
        return ;
    }

    query.prepare("select * from export where staff_no = :staff_no and record_no = :record_no");
    query.bindValue(":staff_no", staff_id);
    query.bindValue(":record_no", record_id);
    query.exec();

    while (query.next())
    {
        QSqlRecord record = query.record();
        flag = query.value(record.indexOf("flag")).toString();

        if (flag == "同意出库请求 " || flag == "同意续租请求 ")
        {
            properties = " rdate = :rdate, flag = :flag ";
            QDate date = QDate::currentDate();
            QString return_date = date.toString("yyyy-MM-dd");
            query.prepare("update export set" + properties + "where staff_no = '" +
                          staff_id + "' and record_no = '" + record_id + "' and flag = '" +
                          flag + "'");
            query.bindValue(":rdate", return_date);
            query.bindValue(":flag", QString("入库请求"));
            query.exec();

            if (query.isActive())
                QMessageBox::information(this, tr("提示"), tr("入库请求申请成功！ "));
            else
                QMessageBox::warning(this, tr("警告"), tr("入库请求申请失败！ "));
        }
        else
            QMessageBox::warning(this, tr("警告"), tr("没有员工已出库或续租的信息！ "));
    }
}


void staff_system_form::on_cancel_btn_2_clicked()
{
    ui->staff_no_le_3->setText("");
    ui->record_no_le_3->setText("");
}


void staff_system_form::on_quit_btn_clicked()
{
    this->close();
    user_login *user_login = new class user_login();
    user_login->show();
    user_login->move((QApplication::desktop()->width() - user_login->width()) / 2,
                     (QApplication::desktop()->height() - user_login->height()) / 2);
}


void staff_system_form::on_fresh_btn_clicked()
{
    record_export_model->setFilter(QObject::tr("record_no like '%'"));
    record_export_model->select();
}


