#ifndef ADMIN_FORM_H
#define ADMIN_FORM_H

#include <QWidget>
#include <QString>
#include <QSqlTableModel>
#include <QSqlRelationalTableModel>

namespace Ui {
class admin_form;
}

class admin_form : public QWidget
{
    Q_OBJECT

public:
    explicit admin_form(QWidget *parent = nullptr);
    ~admin_form();

private:
    void emptyMap();

private slots:
    //选项卡1
    void on_dis_all_btn_1_clicked();//显示全部1
    void on_query_btn_clicked();    //搜索
    void on_add_btn_1_clicked();    //添加1
    void on_alter_btn_1_clicked();  //修改1
    void on_dele_btn_1_clicked();   //删除1
    //选项卡2
    void on_dis_all_btn_2_clicked();//显示全部2
    void on_add_btn_2_clicked();    //添加2
    void on_alter_btn_2_clicked();  //修改2
    void on_dele_btn_2_clicked();   //删除2
    //选项卡3
    void on_b_acc_btn_clicked();    //接受b
    void on_b_refu_btn_clicked();   //拒绝b
    void on_c_acc_btn_clicked();    //接受c
    void on_c_refu_btn_clicked();   //拒绝c
    void on_r_acc_btn_clicked();
    void on_r_refu_btn_clicked();
    void on_quit_btn_clicked();     //quit
    void on_fresh_btn_clicked();    //刷新
    void on_c_fresh_btn_clicked();  //刷新
    void on_r_fresh_btn_clicked();  //刷新
    void timerUpdateView();         //定时更新

private:
    Ui::admin_form  *ui;
    QSqlTableModel *record_manage_model;    //管理记录
    QSqlTableModel *staff_manage_model;     //管理员工
    QSqlTableModel *export_manage_model;    //管理出口表
    QString         record_id_global;
    QMap<QString, bool> staff_export_map;  //员工出口表
    QMap<QString, bool>::iterator staff_export_itera;   //员工出口表迭代器
};

#endif // ADMIN_FORM_H
