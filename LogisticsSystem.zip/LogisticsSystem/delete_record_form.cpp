#include "delete_record_form.h"
#include "ui_delete_record_form.h"
#include "delete_ensure_form.h"
#include <QMessageBox>
#include <QString>
#include <QSqlQuery>
#include <QDesktopWidget>

delete_record_form::delete_record_form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::delete_record_form)
{
    ui->setupUi(this);
    this->setWindowTitle("删除物流记录");
    setWindowIcon(QIcon(":/logo.ico"));
}

delete_record_form::~delete_record_form()
{
    delete ui;
}

void delete_record_form::on_ensure_btn_clicked()
{
    QString record_id;
    QSqlQuery query;

    record_id = ui->record_no_le->text().trimmed();
    query.exec("select record_no from warehouse where record_no = '" + record_id + "'");

    if (query.next())
    {
        query.prepare("delete from warehouse where record_no = :record_id");
        query.bindValue(":record_id", record_id);
        query.exec();

        if (query.isActive())
        {
            delete_ensure_form *delete_ensure = new delete_ensure_form();
            delete_ensure->show();
            delete_ensure->move((QApplication::desktop()->width() - delete_ensure->width()) / 2,
                                (QApplication::desktop()->height() - delete_ensure->height()) / 2);
            this->close();
        }
    }
    else
        QMessageBox::warning(this, tr("错误"), tr("不存在该物流记录！"));
}


void delete_record_form::on_cancel_btn_clicked()
{
    this->close();
}
