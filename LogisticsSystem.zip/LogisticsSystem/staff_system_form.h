#ifndef STAFF_SYSTEM_FORM_H
#define STAFF_SYSTEM_FORM_H

#include <QVector>
#include <QMap>
#include <QWidget>
#include <QSqlQueryModel>
#include <QSqlRelationalTableModel>

namespace Ui {
class staff_system_form;
}

class staff_system_form : public QWidget
{
    Q_OBJECT

public:
    explicit staff_system_form(QWidget *parent = nullptr);
    ~staff_system_form();

private:
    void record_noBind();
    void emptyrecordMap();
    void emptyexportMap();
    void emptySomeMap(QString record_id);

private slots:
    void on_search_btn_clicked();
    void on_dis_all_btn_clicked();
    void on_reset_btn_1_clicked();
    void on_locate_btn_clicked();
    void on_cust_name_ckx_clicked();//按客户名查找
    void on_cust_phone_ckx_clicked();//按客户电话查找
    void on_staff_name_ckx_clicked();//按员工名查找
    void on_add_btn_clicked();
    void on_delete_btn_clicked();
    void on_reset_btn_2_clicked();
    void on_done_btn_clicked();
    void on_add_btn_2_clicked();
    void on_accept_btn_clicked();
    void on_cancel_btn_clicked();
    void on_accept_btn_2_clicked();
    void on_cancel_btn_2_clicked();
    void on_quit_btn_clicked();
    void on_fresh_btn_clicked();
    void timerUpdateView();

private:
    Ui::staff_system_form *ui;
    QSqlQueryModel *record_query_model;
    QSqlTableModel *record_export_model;
    QString properties;
    QString tables;
    QVector<QString>   record_id_order;
    QMap<QString, int> record_num_map;
    QMap<QString, int>::iterator record_itera;
    QMap<QString, int> renew_num_map;
    QMap<QString, int>::iterator renew_itera;
};

#endif // STAFF_SYSTEM_FORM_H
