#ifndef ALTER_STAFF_FORM_H
#define ALTER_STAFF_FORM_H

#include <QWidget>

namespace Ui {
class alter_staff_form;
}

class alter_staff_form : public QWidget
{
    Q_OBJECT

public:
    explicit alter_staff_form(QWidget *parent = nullptr);
    ~alter_staff_form();

private slots:
    void on_ensure_btn_clicked();
    void on_reset_btn_clicked();
    void on_cancel_btn_clicked();
    void displayAllInformation(QString data);

private:
    Ui::alter_staff_form *ui;
    QString staff_id_global;
};

#endif // ALTER_STAFF_FORM_H
