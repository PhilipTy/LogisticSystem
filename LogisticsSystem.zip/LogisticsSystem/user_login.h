#ifndef USER_LOGIN_H
#define USER_LOGIN_H

#include "admin_form.h"
#include "staff_system_form.h"
#include <QWidget>
#include <QDialog>
#include <QString>
#include <QMap>


namespace Ui {
class user_login;
}

class user_login : public QWidget
{
    Q_OBJECT

public:
    explicit user_login(QWidget *parent = nullptr);
    ~user_login();

private slots:
    void on_login_btn_clicked();
    void on_quit_btn_clicked();
    void on_reg_btn_clicked();


private:
    Ui::user_login *ui;
    int admin_counter;
    int staff_counter;
    int counter;
};

#endif // USER_LOGIN_H
