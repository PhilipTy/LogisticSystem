#include "staff_id_form.h"
#include "ui_staff_id_form.h"
#include "alter_staff_form.h"
#include <QMessageBox>
#include <QString>
#include <QSqlQuery>
#include <QDesktopWidget>

staff_id_form::staff_id_form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::staff_id_form)
{
    ui->setupUi(this);
    this->setWindowTitle("输入要修改的员工账号");
    setWindowIcon(QIcon(":/logo.ico"));
}

staff_id_form::~staff_id_form()
{
    delete ui;
}

void staff_id_form::on_ensure_btn_clicked()
{
    QString staff_id;
    QSqlQuery query;

    staff_id = ui->staff_no_le ->text().trimmed();
    query.exec("select staff_no from staff where staff_no = '" + staff_id + "'");

    if (query.next())
    {
        alter_staff_form *alter_staff = new alter_staff_form();
        alter_staff->show();
        alter_staff->move((QApplication::desktop()->width() - alter_staff->width()) / 2,
                         (QApplication::desktop()->height() - alter_staff->height()) / 2);
        connect(this, SIGNAL(send_staff_id(QString)), alter_staff, SLOT(displayAllInformation(QString)));
        emit send_staff_id(staff_id);

        this->close();
    }
    else
        QMessageBox::warning(this, tr("错误"), tr("没有找到相关记录信息！"));
}

void staff_id_form::on_cancel_btn_clicked()
{
    this->close();
}
