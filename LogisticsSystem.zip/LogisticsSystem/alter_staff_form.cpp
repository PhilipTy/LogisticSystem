#include "alter_staff_form.h"
#include "ui_alter_staff_form.h"
#include <QMessageBox>
#include <QString>
#include <QSqlQuery>

alter_staff_form::alter_staff_form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::alter_staff_form)
{
    ui->setupUi(this);
    this->setWindowTitle("修改员工信息");
    setWindowIcon(QIcon(":/logo.ico"));
}

alter_staff_form::~alter_staff_form()
{
    delete ui;
}


void alter_staff_form::displayAllInformation(QString data)
{
    QString staff_id;
    QSqlQuery query;

    staff_id = data;
    staff_id_global = data;

    query.exec("select * from staff where staff_no = '" + staff_id + "'");

    if (query.next())
    {
        ui->staff_no_le->setText(query.value(0).toString());
        ui->staff_name_le->setText(query.value(1).toString());
        ui->staff_key_le->setText(query.value(3).toString());
        ui->staff_tel_le->setText(query.value(2).toString());
        ui->staff_sex_cbx->setCurrentText(query.value(4).toString());
    }
    else
        QMessageBox::warning(this, tr("警告"), tr("没有此员工的相关信息！ "));
}


void alter_staff_form::on_ensure_btn_clicked()
{
    QString staff_id;
    QString staff_name;
    QString staff_tel;
    QString staff_key;
    QString staff_sex;
    QString admin;
    QSqlQuery query;

    staff_id = ui->staff_no_le->text();
    staff_name = ui->staff_name_le->text();
    staff_tel = ui->staff_tel_le->text();
    staff_key = ui->staff_key_le->text();
    staff_sex = ui->staff_sex_cbx->currentText();
    admin = "0000";

    if (staff_id == staff_id_global)
    {
        query.prepare("update staff set staff_name = :name, staff_key = :key, staff_tel = :tel, staff_sex = :sex where staff_no = :id");
        query.bindValue(":id", staff_id);
        query.bindValue(":name", staff_name);
        query.bindValue(":key", staff_key);
        query.bindValue(":tel", staff_tel);
        query.bindValue(":sex", staff_sex);
        query.exec();

        if (query.isActive())
        {
            QMessageBox::information(this, tr("信息"), tr("员工信息修改成功！"));
            this->close();
        }
        else
            QMessageBox::warning(this, tr("警告"), tr("员工信息修改失败！"));
    }
    else
    {
        QMessageBox::warning(this, tr("警告"), tr("员工账号不能修改！"));
        ui->staff_no_le->setText(staff_id_global);
    }
}


void alter_staff_form::on_reset_btn_clicked()
{
    ui->staff_name_le->setText("");
    ui->staff_tel_le->setText("");
    ui->staff_key_le->setText("");
    ui->staff_sex_cbx->setCurrentText("");
}


void alter_staff_form::on_cancel_btn_clicked()
{
    this->close();
}
