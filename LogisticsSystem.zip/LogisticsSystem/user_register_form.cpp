#include "user_register_form.h"
#include "ui_user_register_form.h"

#include <QMessageBox>
#include <QString>
#include <QSqlQuery>

user_register_form::user_register_form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::user_register_form)
{
    ui->setupUi(this);
    this->setWindowTitle("员工注册");
    setWindowIcon(QIcon(":/logo.ico"));
}

user_register_form::~user_register_form()
{
    delete ui;
}


void user_register_form::on_yes_btn_clicked()
{
    QString staff_name;
    QString staff_no;
    QString staff_key;
    QString staff_key_confim;
    QString staff_tel;
    QString staff_sex;
    QString properties;
    QString values;

    QSqlQuery query;

    /*输入检测*/
    if (!ui->staff_name_le->text().trimmed().isEmpty())
        staff_name = ui->staff_name_le->text().trimmed();
    else
    {
        QMessageBox::warning(this, tr("警告"), tr("用户名不能为空！"));
        return ;
    }

    if (!ui->staff_no_le->text().trimmed().isEmpty())
        staff_no = ui->staff_no_le->text().trimmed();
    else
    {
        QMessageBox::warning(this, tr("警告"), tr("账号不能为空！"));
        return ;
    }

    if (!ui->staff_key_le->text().trimmed().isEmpty())
        staff_key = ui->staff_key_le->text().trimmed();
    else
    {
        QMessageBox::warning(this, tr("警告"), tr("密码不能为空！"));
        return ;
    }

    if (!ui->staff_key_confim_le->text().trimmed().isEmpty())
        staff_key_confim = ui->staff_key_confim_le->text().trimmed();
    else
    {
        QMessageBox::warning(this, tr("警告"), tr("确认密码不能为空！"));
        return ;
    }

    staff_tel = ui->staff_tel_le->text().trimmed();
    staff_sex = ui->staff_sex_cmx->currentText().trimmed();

    if (staff_key.compare(staff_key_confim) != 0)
    {
        QMessageBox::warning(this, tr("警告"), tr("两次输入密码不同！"));
        return ;
    }


    query.exec("select * from staff where staff_no = '" + staff_no + "'");

    if(!query.next())
    {
        properties = "staff_no, staff_name, staff_key, staff_tel, staff_sex, ano";
        values = ":staff_no, :staff_name, :staff_key, :staff_tel, :staff_sex, :ano";
        query.prepare("insert into staff(" + properties + ") values(" +
                      values + ")");
        query.bindValue(":staff_no", staff_no);
        query.bindValue(":staff_name", staff_name);
        query.bindValue(":staff_key", staff_key);
        query.bindValue(":staff_tel", staff_tel);
        query.bindValue(":staff_sex", staff_sex);
        query.bindValue(":ano", QString("0000"));
        query.exec();

        if (query.isActive())
        {
            QMessageBox::information(this, tr("提示"), tr("注册成功"));
            this->close();
        }
    }
    else
        QMessageBox::warning(this, tr("警告"), tr("所注册的用户已存在！"));
}


void user_register_form::on_no_btn_clicked()
{
    this->close();
}
