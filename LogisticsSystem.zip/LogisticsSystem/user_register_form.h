#ifndef USER_REGISTER_FORM_H
#define USER_REGISTER_FORM_H

#include <QWidget>

namespace Ui {
class user_register_form;
}

class user_register_form : public QWidget
{
    Q_OBJECT

public:
    explicit user_register_form(QWidget *parent = nullptr);
    ~user_register_form();

private slots:
    void on_yes_btn_clicked();
    void on_no_btn_clicked();

private:
    Ui::user_register_form *ui;
};

#endif // USER_REGISTER_FORM_H
