#include "alter_record_form.h"
#include "ui_alter_record_form.h"
#include <QMessageBox>
#include <QString>
#include <QSqlQuery>


alter_record_form::alter_record_form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::alter_record_form)
{
    ui->setupUi(this);
    this->setWindowTitle("修改物流信息");
    setWindowIcon(QIcon(":/logo.ico"));
}

alter_record_form::~alter_record_form()
{
    delete ui;
}


void alter_record_form::displayAllInformation(QString data)
{
    QString record_id;
    QSqlQuery query;

    record_id = data;
    record_id_global = data;

    query.exec("select * from warehouse where record_no = '" + record_id + "'");

    if (query.next())
    {
        ui->record_no_le->setText(query.value(0).toString());
        ui->cust_name_le->setText(query.value(1).toString());
        ui->address_le->setText(query.value(2).toString());
        ui->cust_phone_le->setText(query.value(3).toString());
        ui->staff_le->setText(query.value(4).toString());
        ui->state_le->setText(query.value(5).toString());
    }
    else
        QMessageBox::warning(this, tr("警告"), tr("不存在该物流记录！！"));
}


void alter_record_form::on_ensure_btn_clicked()
{
    QString record_id;
    QString cust_name;
    QString address;
    QString staff_name;
    QString cust_phone;
    QString number;
    QString admin;
    QSqlQuery query;

    record_id = ui->record_no_le->text();
    cust_name = ui->cust_name_le->text();
    address = ui->address_le->text();
    staff_name = ui->staff_le->text();
    cust_phone = ui->cust_phone_le->text();
    number = ui->state_le->text();
    admin = "0000";

    if (record_id == record_id_global)
    {
        query.prepare("update warehouse set cust_name = :name, addno = :address, cust_phone = :cust_phone, staff_name = :staff_name, bnum = :num where record_no = :id");
        query.bindValue(":id", record_id);
        query.bindValue(":name", cust_name);
        query.bindValue(":address", address);
        query.bindValue(":cust_phone", cust_phone);
        query.bindValue(":staff_name", staff_name);
        query.bindValue(":num", number);
        query.exec();

        if (query.isActive())
        {
            QMessageBox::information(this, tr("信息"), tr("物流信息修改成功！"));
            this->close();
        }
        else
            QMessageBox::warning(this, tr("警告"), tr("物流信息修改失败！"));
    }
    else
    {
        QMessageBox::warning(this, tr("警告"), tr("物流号不能修改！"));
        ui->record_no_le->setText(record_id_global);
    }
}


void alter_record_form::on_reset_btn_clicked()
{
    ui->cust_name_le->setText("");
    ui->cust_phone_le->setText("");
    ui->address_le->setText("");
    ui->staff_le->setText("");
    ui->state_le->setText("");
}


void alter_record_form::on_cancel_btn_clicked()
{
    this->close();
}
