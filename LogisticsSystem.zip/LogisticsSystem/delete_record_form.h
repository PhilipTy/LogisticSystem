#ifndef DELETE_RECORD_FORM_H
#define DELETE_RECORD_FORM_H

#include <QWidget>

namespace Ui {
class delete_record_form;
}

class delete_record_form : public QWidget
{
    Q_OBJECT

public:
    explicit delete_record_form(QWidget *parent = nullptr);
    ~delete_record_form();

private slots:
    void on_ensure_btn_clicked();
    void on_cancel_btn_clicked();

private:
    Ui::delete_record_form *ui;
};

#endif // DELETE_RECORD_FORM_H
