#ifndef STAFF_ID_FORM_H
#define STAFF_ID_FORM_H

#include <QWidget>

namespace Ui {
class staff_id_form;
}

class staff_id_form : public QWidget
{
    Q_OBJECT

public:
    explicit staff_id_form(QWidget *parent = nullptr);
    ~staff_id_form();

private:
signals:
    void send_staff_id(QString);

private slots:
    void on_ensure_btn_clicked();
    void on_cancel_btn_clicked();

private:
    Ui::staff_id_form *ui;
};

#endif // STAFF_ID_FORM_H
