#include "delete_staff_form.h"
#include "ui_delete_staff_form.h"
#include "delete_ensure_form.h"
#include <QMessageBox>
#include <QString>
#include <QSqlQuery>
#include <QDesktopWidget>

delete_staff_form::delete_staff_form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::delete_staff_form)
{
    ui->setupUi(this);
    this->setWindowTitle("删除员工");
    setWindowIcon(QIcon(":/logo.ico"));
}

delete_staff_form::~delete_staff_form()
{
    delete ui;
}

void delete_staff_form::on_ensure_btn_clicked()
{
    QString staff_id;
    QSqlQuery query;

    staff_id = ui->staff_no_le->text().trimmed();
    query.exec("select staff_no from staff where staff_no = '" + staff_id + "'");

    if (query.next())
    {
        query.prepare("delete from staff where staff_no = :staff_id");
        query.bindValue(":staff_id", staff_id);
        query.exec();

        if (query.isActive())
        {
            QMessageBox::information(this, tr("信息"), tr("删除记录成功！"));
            this->close();
        }
    }
    else
        QMessageBox::warning(this, tr("错误"), tr("没有此员工记录! "));
}


void delete_staff_form::on_cancel_btn_clicked()
{
    this->close();
}
