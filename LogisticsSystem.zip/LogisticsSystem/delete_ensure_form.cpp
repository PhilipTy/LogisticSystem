#include "delete_ensure_form.h"
#include "ui_delete_ensure_form.h"
#include <QMessageBox>

delete_ensure_form::delete_ensure_form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::delete_ensure_form)
{
    ui->setupUi(this);
    this->setWindowTitle("确认删除?");
    setWindowIcon(QIcon(":/logo.ico"));
}

delete_ensure_form::~delete_ensure_form()
{
    delete ui;
}

void delete_ensure_form::on_yes_btn_clicked()
{
    QMessageBox::information(this, tr("信息"), tr("删除记录成功！"));
    this->close();
}


void delete_ensure_form::on_no_btn_clicked()
{
    this->close();
}
