#include "admin_form.h"
#include "ui_admin_form.h"
#include "user_login.h"
#include "add_record_form.h"
#include "delete_record_form.h"
#include "add_staff_form.h"
#include "delete_staff_form.h"
#include "record_id_form.h"
#include "staff_id_form.h"
#include "ui_staff_system_form.h"

#include <QTimer>
#include <QDate>
#include <QString>
#include <QDebug>
#include <QMessageBox>
#include <QTableWidget>
#include <QDesktopWidget>
#include <QAbstractItemView>
#include <QModelIndex>
#include <QSqlQuery>
#include <QSqlRecord>


admin_form::admin_form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::admin_form)
{
    ui->setupUi(this);
    this->setWindowTitle("管理员系统");
    setWindowIcon(QIcon(":/logo.ico"));
    ui->admin_tw->setCurrentIndex(0);

    record_manage_model = new QSqlTableModel(this);
    record_manage_model->setTable("warehouse");
    record_manage_model->setEditStrategy(QSqlTableModel::OnManualSubmit);
    record_manage_model->setHeaderData(0, Qt::Horizontal, tr("物流号"));
    record_manage_model->setHeaderData(1, Qt::Horizontal, tr("客户姓名"));
    record_manage_model->setHeaderData(2, Qt::Horizontal, tr("地址"));
    record_manage_model->setHeaderData(3, Qt::Horizontal, tr("客户电话"));
    record_manage_model->setHeaderData(4, Qt::Horizontal, tr("负责员工"));
    record_manage_model->setHeaderData(5, Qt::Horizontal, tr("数量"));
    record_manage_model->removeColumn(record_manage_model->fieldIndex("ano"));
    record_manage_model->select();

    ui->recordlist_tv->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->recordlist_tv->setModel(record_manage_model);
    ui->recordlist_tv->show();

    staff_manage_model = new QSqlTableModel(this);
    staff_manage_model->setTable("staff");
    staff_manage_model->setEditStrategy(QSqlTableModel::OnManualSubmit);
    staff_manage_model->setHeaderData(0, Qt::Horizontal, tr("员工帐号"));
    staff_manage_model->setHeaderData(1, Qt::Horizontal, tr("员工姓名"));
    staff_manage_model->setHeaderData(2, Qt::Horizontal, tr("员工密码"));
    staff_manage_model->setHeaderData(3, Qt::Horizontal, tr("员工电话"));
    staff_manage_model->setHeaderData(4, Qt::Horizontal, tr("员工性别"));
    staff_manage_model->setHeaderData(5, Qt::Horizontal, tr("管理员号"));
    staff_manage_model->select();

    ui->staff_tw->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->staff_tw->setModel(staff_manage_model);
    ui->staff_tw->show();

    export_manage_model = new QSqlTableModel(this);
    export_manage_model->setTable("export");
    export_manage_model->setEditStrategy(QSqlTableModel::OnManualSubmit);
    export_manage_model->setHeaderData(0, Qt::Horizontal, tr("员工帐号"));
    export_manage_model->setHeaderData(1, Qt::Horizontal, tr("物流号" ));
    export_manage_model->setHeaderData(2, Qt::Horizontal, tr("出库日期"));
    export_manage_model->setHeaderData(3, Qt::Horizontal, tr("物流期限"));
    export_manage_model->setHeaderData(4, Qt::Horizontal, tr("入库日期"));
    export_manage_model->setHeaderData(5, Qt::Horizontal, tr("物流状态"));
    export_manage_model->select();

    ui->export_tv->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->export_tv->setModel(export_manage_model);
    ui->export_tv->show();

    this->emptyMap();

    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(timerUpdateView()));
    timer->start(5000);
}


admin_form::~admin_form()
{
    delete ui;
}


void admin_form::emptyMap()
{
    QString staff_id;
    QSqlQuery query;
    QSqlRecord record;
    query.exec("select * from staff");

    while (query.next())
    {
        record = query.record();
        staff_id = query.value(record.indexOf("staff_no")).toString();
        staff_export_map.insert(staff_id, 1);
    }
}


void admin_form::timerUpdateView()
{
//    record_manage_model->setFilter(QObject::tr("record_no like '%1'").arg("%"));
//    record_manage_model->select();

//    staff_manage_model->setFilter(QObject::tr("staff_no like '%1'").arg("%"));
//    staff_manage_model->select();

    export_manage_model->setFilter(QObject::tr("staff_no like '%1'").arg("%"));
    export_manage_model->select();
}


void admin_form::on_dis_all_btn_1_clicked()
{
    record_manage_model->setFilter(QObject::tr("record_no like '%1'").arg("%"));
    record_manage_model->select();
}


void admin_form::on_query_btn_clicked()
{
    QString query_type;
    QString query_text;
    QString select_text;

    query_type = ui->type_cbx->currentText();
    query_text = ui->query_le->text();

    if (query_type == tr("客户姓名"))
        select_text += "cust_name like'" + query_text + "%'";
    if (query_type == tr("物流号"))
        select_text = "record_no like'" + query_text + "%'";

    record_manage_model->setFilter(select_text);
    record_manage_model->select();
}


void admin_form::on_add_btn_1_clicked()
{
    add_record_form *add_record = new add_record_form();
    add_record->show();
    add_record->move((QApplication::desktop()->width() - add_record->width()) / 2,
                   (QApplication::desktop()->height() - add_record->height()) / 2);
}


void admin_form::on_alter_btn_1_clicked()
{
    record_id_form *record_id = new record_id_form();
    record_id->show();
    record_id->move((QApplication::desktop()->width() - record_id->width()) / 2,
                  (QApplication::desktop()->height() - record_id->height()) / 2);
}


void admin_form::on_dele_btn_1_clicked()
{
    delete_record_form *delete_book = new delete_record_form();
    delete_book->show();
    delete_book->move((QApplication::desktop()->width() - delete_book->width()) / 2,
                      (QApplication::desktop()->height() - delete_book->height()) / 2);
}


void admin_form::on_dis_all_btn_2_clicked()
{
    staff_manage_model->setFilter("staff_no like '%'");
    staff_manage_model->select();
}


void admin_form::on_add_btn_2_clicked()
{
    add_staff_form *add_staff = new add_staff_form();
    add_staff->show();
    add_staff->move((QApplication::desktop()->width() - add_staff->width()) / 2,
                     (QApplication::desktop()->height() - add_staff->height()) / 2);
}


void admin_form::on_alter_btn_2_clicked()
{
    staff_id_form *staff_id = new staff_id_form();
    staff_id->show();
    staff_id->move((QApplication::desktop()->width() - staff_id->width()) / 2,
                    (QApplication::desktop()->height() - staff_id->height()) / 2);
}


void admin_form::on_dele_btn_2_clicked()
{
    delete_staff_form *delete_staff = new delete_staff_form();
    delete_staff->show();
    delete_staff->move((QApplication::desktop()->width() - delete_staff->width()) / 2,
                        (QApplication::desktop()->height() - delete_staff->height()) / 2);
}


void admin_form::on_b_acc_btn_clicked()
{
    QString record_id;
    QString number;
    QString staff_id;
    QString flag;
    QSqlQuery query;
    QSqlQuery query_delete;
    QSqlQuery query_update;
    QDate end_date;
    QDate current_date = QDate::currentDate();

    QModelIndex index = ui->export_tv->currentIndex();
    record_id = export_manage_model->record(index.row()).value("record_no").toString();
    staff_id = export_manage_model->record(index.row()).value("staff_no").toString();
    flag = export_manage_model->record(index.row()).value("flag").toString();

    query.exec("select * from export where staff_no = '" + staff_id + "'");

    while (query.next())
    {
        QSqlRecord record = query.record();
        end_date = query.value(record.indexOf("edate")).toDate();
        flag = query.value(record.indexOf("flag")).toString();
        int days = current_date.daysTo(end_date);

        if (days < 0)
        {
            if (flag == "同意出库请求 " || "同意续租请求 ")
            {
                QMessageBox::warning(this, tr("警告"),
                                     tr("已出库物流续租超过流通终期限并未入库，无法出库！"));
                query_delete.exec("delete from export where record_no = '" + record_id +
                                  "' and staff_no = '" + staff_id +
                                  "' and flag = '出库请求'");

                if (query_delete.isActive())
                {
                    QMessageBox::information(this, tr("提示"), tr("管理员取消员工出库权利！ "));
                    export_manage_model->setFilter(QObject::tr("record_no like '%'"));
                    export_manage_model->select();

                    query_update.prepare("update warehouse set bnum = :bnum where record_no = :record_no");
                    query_update.bindValue(":record_no", record_id);
                    query_update.bindValue(":bnum", number + 1);
                    query_update.exec();

                    if (query_update.isActive())
                    {
                        QMessageBox::information(this, tr("提示"), tr("更新物流表成功！ "));
                        record_manage_model->setFilter(QObject::tr("record_no like '%'"));
                        record_manage_model->select();
                    }
                }
                return ;
            }
        }
    }

    query.exec("select * from warehouse where record_no = '" + record_id + "'");

    if (query.next())
    {
        QSqlRecord record = query.record();
        number = query.value(record.indexOf("bnum")).toInt();
    }

    if (flag == "出库请求")
    {
        query.prepare("update export set flag = :flag where staff_no = '" +
                      staff_id + "' and record_no = '" +
                      record_id + "' and flag = '" + flag + "'");
        query.bindValue(":flag", QString("同意出库请求"));
        query.exec();

        if (query.isActive())
        {
            QMessageBox::information(this, tr("提示"), tr("管理员同意员工出库请求！ "));
            export_manage_model->setFilter(QObject::tr("record_no like '%'"));
            export_manage_model->select();
        }
        else
            QMessageBox::warning(this, tr("警告"), tr("更新员工出库请求失败！"));
    }
    else
        QMessageBox::warning(this, tr("警告"), tr("当前没有员工的出库请求！"));
}


void admin_form::on_b_refu_btn_clicked()
{
    QString record_id;
    QString staff_id;
    QString flag;
    int number;

    QSqlQuery query;
    QSqlQuery query_update;
    QSqlQuery query_delete;

    QModelIndex index = ui->export_tv->currentIndex();
    record_id = export_manage_model->record(index.row()).value("record_no").toString();
    staff_id = export_manage_model->record(index.row()).value("staff_no").toString();
    flag = export_manage_model->record(index.row()).value("flag").toString();

    query.exec("select * from warehouse where record_no = '" + record_id + "'");

    if (query.next())
    {
        QSqlRecord record = query.record();
        number = query.value(record.indexOf("bnum")).toInt();
    }

    if (flag == "出库请求")
    {
        query_delete.exec("delete from export where record_no = '" + record_id +
                          "' and staff_no = '" + staff_id +
                          "' and flag = '" + flag + "'");

        if (query_delete.isActive())
        {
            QMessageBox::information(this, tr("提示"), tr("管理员拒绝员工出库请求！"));
            export_manage_model->setFilter(QObject::tr("record_no like '%'"));
            export_manage_model->select();

            query_update.prepare("update warehouse set bnum = :bnum where record_no = :record_no");
            query_update.bindValue(":record_no", record_id);
            query_update.bindValue(":bnum", number + 1);
            query_update.exec();

            if (query_update.isActive())
            {
                QMessageBox::information(this, tr("提示"), tr("更新物流表成功！"));
                record_manage_model->setFilter(QObject::tr("record_no like '%'"));
                record_manage_model->select();
            }
        }
        else
            QMessageBox::warning(this, tr("警告"), tr("删除员工出库请求失败"));
    }
    else
        QMessageBox::warning(this, tr("警告"), tr("当前没有员工的出库请求！"));
}


void admin_form::on_c_fresh_btn_clicked()
{
    QString record_id;
    QString staff_id;
    QSqlQuery query;

    query.exec("select * from export where flag = '续租请求'");
    if (query.next())
    {
        QSqlRecord record = query.record();
        record_id = query.value(record.indexOf("record_no")).toString();
        staff_id = query.value(record.indexOf("staff_no")).toString();

        ui->c_staff_no_le->setText(staff_id);
        ui->c_record_no_le->setText(record_id);
    }
    else
        QMessageBox::information(this, tr("提示"), tr("没有员工续租请求！"));
}


void admin_form::on_r_fresh_btn_clicked()
{
    QString record_id;
    QString staff_id;
    QSqlQuery query;

    query.exec("select * from export where flag = '入库请求'");
    if (query.next())
    {
        QSqlRecord record = query.record();
        record_id = query.value(record.indexOf("record_no")).toString();
        staff_id = query.value(record.indexOf("staff_no")).toString();

        ui->r_staff_no_le->setText(staff_id);
        ui->r_record_no_le->setText(record_id);
    }
    else
        QMessageBox::information(this, tr("提示"), tr("没有员工入库请求！"));
}


void admin_form::on_c_acc_btn_clicked()
{
    QString record_id;
    QString staff_id;
    QSqlQuery query;
    QSqlQuery query_update;

    record_id = ui->c_record_no_le->text();
    staff_id = ui->c_staff_no_le->text();

    query.exec("select * from export where staff_no = '" + staff_id +"' and record_no = '" +
               record_id + "' and flag = '续租请求'");

    if (!query.next())
    {
        QMessageBox::warning(this, tr("警告"), tr("出库表中没有对应员工的续租请求！"));
        return ;
    }

    query.exec("select * from export where staff_no = '" + staff_id +"' and record_no = '" +
               record_id + "' and flag = '续租请求'");

    while (query.next())
    {
        query_update.prepare("update export set flag = :flag where staff_no = '" +
                             staff_id + "' and record_no = '" + record_id +
                             "' and flag = '续租请求'");
        query_update.bindValue(":flag", QString("同意续租请求 "));
        query_update.exec();

        if (query_update.isActive())
        {
            QMessageBox::information(this, tr("提示"), tr("管理员同意员工续租请求！"));
            export_manage_model->setFilter(QObject::tr("record_no like '%'"));
            export_manage_model->select();
        }
        else
            QMessageBox::warning(this, tr("警告"), tr("更新员工续租请求失败！"));
    }
}


void admin_form::on_c_refu_btn_clicked()
{
    QString record_id;
    QString staff_id;
    QString end_date;
    QString properties;
    QDate start_date;
    QSqlQuery query;
    QSqlQuery query_update;

    record_id = ui->c_record_no_le->text();
    staff_id = ui->c_staff_no_le->text();

    query.exec("select * from export where staff_no = '" + staff_id +"' and record_no = '" +
               record_id + "' and flag = '续租请求'");

    if (!query.next())
    {
        QMessageBox::warning(this, tr("警告"), tr("出库表中没有对应员工的续租请求！"));
        return ;
    }

    query.exec("select * from export where staff_no = '" + staff_id +"' and record_no = '" +
               record_id + "' and flag = '续租请求'");

    while (query.next())
    {
        QSqlRecord record = query.record();
        start_date = query.value(record.indexOf("sdate")).toDate();

        properties = " edate = :edate, flag = :flag ";
        end_date = start_date.addDays(30).toString("yyyy-MM-dd");
        query_update.prepare("update export set" + properties +
                             "where staff_no = '" + staff_id + "' and record_no = '" +
                             record_id + "' and flag = '续租请求'");
        query_update.bindValue(":edate", end_date);
        query_update.bindValue(":flag", QString("拒绝续租请求"));
        query_update.exec();

        if (query_update.isActive())
        {
            QMessageBox::information(this, tr("提示"), tr("管理员拒绝员工续租请求！"));
            export_manage_model->setFilter(QObject::tr("record_no like '%'"));
            export_manage_model->select();
        }
        else
            QMessageBox::warning(this, tr("警告"), tr("没法更新员工续租请求！"));
    }
}


void admin_form::on_r_acc_btn_clicked()
{
    QString record_id;
    QString staff_id;
    int number;

    QSqlQuery query;
    QSqlQuery query_update;

    record_id = ui->r_record_no_le->text();
    staff_id = ui->r_staff_no_le->text();

    query.exec("select * from export where staff_no = '" + staff_id +"' and record_no = '" +
               record_id + "' and flag = '入库请求'");

    if (!query.next())
    {
        QMessageBox::warning(this, tr("警告"), tr("出库表中没有对应的员工入库请求！"));
        return ;
    }

    query.exec("select * from export where staff_no = '" + staff_id +"' and record_no = '" +
               record_id + "' and flag = '入库请求'");

    while (query.next())
    {
        query.exec("select * from warehouse where record_no = '" + record_id + "'");

        if (query.next())
        {
            QSqlRecord record = query.record();
            number = query.value(record.indexOf("bnum")).toInt();
        }

        query_update.prepare("update export set flag = :flag where staff_no = '" +
                             staff_id + "' and record_no = '" + record_id +
                             "' and flag = '入库请求'");
        query_update.bindValue(":flag", "同意入库请求");
        query_update.exec();

        if (query_update.isActive())
        {
            QMessageBox::information(this, tr("提示"), tr("管理员同意员工入库请求！"));
            export_manage_model->setFilter(QObject::tr("record_no like '%'"));
            export_manage_model->select();

            query_update.prepare("update warhouse set bnum = :bnum where record_no = :record_no");
            query_update.bindValue(":record_no", record_id);
            query_update.bindValue(":bnum", number + 1);
            query_update.exec();

            if (query_update.isActive())
            {
                QMessageBox::information(this, tr("提示"), tr("更新物流表成功！"));
                record_manage_model->setFilter(QObject::tr("record_no like '%'"));
                record_manage_model->select();
            }
        }
        else
            QMessageBox::warning(this, tr("警告"), tr("更新员工入库请求失败 "));
    }
}


void admin_form::on_r_refu_btn_clicked()
{
    QString record_id;
    QString staff_id;
    QString properties;
    QSqlQuery query;
    QSqlQuery query_update;

    record_id = ui->r_record_no_le->text();
    staff_id = ui->r_staff_no_le->text();

    query.exec("select * from export where staff_no = '" + staff_id +"' and record_no = '" +
               record_id + "' and flag = '入库请求'");

    if (!query.next())
    {
        QMessageBox::warning(this, tr("警告"), tr("出库表中没有对应员工的入库请求！"));
        return ;
    }

    query.exec("select * from export where staff_no = '" + staff_id +"' and record_no = '" +
               record_id + "' and flag = '入库请求'");

    while (query.next())
    {
        properties = " rdate = :rdate, flag = :flag ";
        query_update.prepare("update export set" + properties +
                             "where staff_no = '" + staff_id + "' and record_no = '" +
                             record_id + "' and flag = '入库请求");
        query_update.bindValue(":rdate", "");
        query_update.bindValue(":flag", "拒绝入库请求");
        query_update.exec();

        if (query_update.isActive())
        {
            QMessageBox::information(this, tr("提示"), tr("管理员拒绝员工入库请求！ "));
            export_manage_model->setFilter(QObject::tr("record_no like '%'"));
            export_manage_model->select();
        }
        else
            QMessageBox::warning(this, tr("警告"), tr("更新员工入库请求失败"));
    }
}


void admin_form::on_quit_btn_clicked()
{
    this->close();
    user_login *user_login = new class user_login();
    user_login->show();
    user_login->move((QApplication::desktop()->width() - user_login->width()) / 2,
                     (QApplication::desktop()->height() - user_login->height()) / 2);
}


void admin_form::on_fresh_btn_clicked()
{
    export_manage_model->setFilter(QObject::tr("record_no like '%'"));
    export_manage_model->select();

    record_manage_model->setFilter(QObject::tr("record_no like '%'"));
    record_manage_model->select();
}
