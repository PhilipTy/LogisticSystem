#include "add_staff_form.h"
#include "ui_add_staff_form.h"
#include <QMessageBox>
#include <QString>
#include <QSqlQuery>


add_staff_form::add_staff_form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::add_staff_form)
{
    ui->setupUi(this);
    this->setWindowTitle("添加员工");
    setWindowIcon(QIcon(":/logo.ico"));
}

add_staff_form::~add_staff_form()
{
    delete ui;
}

void add_staff_form::on_ensure_btn_clicked()
{
    QString staff_id;
    QString staff_name;
    QString staff_tel;
    QString staff_key;
    QString staff_sex;
    QString admin;
    QSqlQuery query;

    staff_id = ui->staff_no_le->text().trimmed();
    staff_name = ui->staff_name_le->text().trimmed();
    staff_tel = ui->staff_tel_le->text().trimmed();
    staff_key = ui->staff_key_le->text().trimmed();
    staff_sex = ui->staff_sex_cbx->currentText().trimmed();
    admin = "0000";

    query.exec("select staff_no from staff where staff_no = '" + staff_id + "'");

    if (!query.next())
    {
        if (staff_id != "" && staff_name != "" && staff_key != "" && staff_tel != "")
        {
                query.prepare(tr("insert into staff values(:id, :name, :key, :tel, :sex, :admin)"));
                query.bindValue(":id", staff_id);
                query.bindValue(":name", staff_name);
                query.bindValue(":key", staff_key);
                query.bindValue(":tel", staff_tel);
                query.bindValue(":sex", staff_sex);
                query.bindValue(":admin", admin);
                query.exec();

                if (query.isActive())
                {
                    query.numRowsAffected();
                    QMessageBox::information(this, tr("信息"), tr("新员工加入成功！"));
                    this->close();
                }
            }
        else
            QMessageBox::warning(this, tr("警告"), tr("员工号、密码、姓名、电话不能为空！"));
    }
    else
    {
        QMessageBox::warning(this, tr("警告"), tr("员工号唯一，不能重复！"));
        return ;
    }
}


void add_staff_form::on_reset_btn_clicked()
{
    ui->staff_no_le->setText("");
    ui->staff_name_le->setText("");
    ui->staff_tel_le->setText("");
    ui->staff_key_le->setText("");
    ui->staff_sex_cbx->setCurrentText("");
}


void add_staff_form::on_cancel_btn_clicked()
{
    this->close();
}
