#ifndef DELETE_STAFF_FORM_H
#define DELETE_STAFF_FORM_H

#include <QWidget>

namespace Ui {
class delete_staff_form;
}

class delete_staff_form : public QWidget
{
    Q_OBJECT

public:
    explicit delete_staff_form(QWidget *parent = nullptr);
    ~delete_staff_form();

private slots:
    void on_ensure_btn_clicked();
    void on_cancel_btn_clicked();

private:
    Ui::delete_staff_form *ui;
};

#endif // DELETE_STAFF_FORM_H
