#ifndef ADD_STAFF_FORM_H
#define ADD_STAFF_FORM_H

#include <QWidget>

namespace Ui {
class add_staff_form;
}

class add_staff_form : public QWidget
{
    Q_OBJECT

public:
    explicit add_staff_form(QWidget *parent = nullptr);
    ~add_staff_form();

private slots:
    void on_ensure_btn_clicked();//确定
    void on_reset_btn_clicked();//重置信息
    void on_cancel_btn_clicked();//取消


private:
    Ui::add_staff_form *ui;
};

#endif // ADD_STAFF_FORM_H
