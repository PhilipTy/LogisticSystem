#ifndef RECORD_ID_FORM_H
#define RECORD_ID_FORM_H

#include <QWidget>

namespace Ui {
class record_id_form;
}

class record_id_form : public QWidget
{
    Q_OBJECT

public:
    explicit record_id_form(QWidget *parent = nullptr);
    ~record_id_form();

private:
signals:
    void send_record_id(QString);//信号函数：修改物流

private slots:
    void on_ensure_btn_clicked();//槽函数：确定
    void on_cancel_btn_clicked();//槽函数：取消

private:
    Ui::record_id_form *ui;
};

#endif // RECORD_ID_FORM_H
